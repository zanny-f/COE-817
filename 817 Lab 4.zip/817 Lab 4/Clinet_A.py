import socket
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
import threading

def receive_messages(sock, group_key):
    while True:
        message = sock.recv(2048)
        if message:
            cipher_aes = AES.new(group_key, AES.MODE_EAX, nonce=message[:16])
            plaintext = cipher_aes.decrypt(message[16:])
            print(f"Client A Received: {plaintext.decode()}")

def send_message(sock, group_key):
    while True:
        message = input("Client A Enter message: ")
        cipher_aes = AES.new(group_key, AES.MODE_EAX)
        nonce = cipher_aes.nonce
        ciphertext, tag = cipher_aes.encrypt_and_digest(message.encode())
        sock.send(nonce + ciphertext)

def main():
    host = 'localhost'
    port = 9999

    client_key = RSA.generate(2048)
    public_key = client_key.publickey().export_key()

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    client_socket.send(public_key)

    encrypted_group_key = client_socket.recv(2048)
    cipher_rsa = PKCS1_OAEP.new(client_key)
    group_key = cipher_rsa.decrypt(encrypted_group_key)

    print("Client B received group key.")

    threading.Thread(target=receive_messages, args=(client_socket, group_key)).start()
    send_message(client_socket, group_key)

if __name__ == "__main__":
    main()
