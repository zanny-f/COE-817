import hashlib
import secrets
import socket
import string
import threading
import os
from datetime import datetime

from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad
from Cryptodome.Random import get_random_bytes
import base64

# Define global variables
MASTER_SECRET = None
MAC_KEY = None
DEK = None
HOST = '127.0.0.1'
PORT = 65432
CREDENTIALS_FILE = os.path.join(os.path.dirname(__file__), 'credentials.txt')
SHARED_KEY = b'SymmetricAuthKey'
BLOCK_SIZE = 16

# Ensure credentials file exists with default users if empty
os.makedirs(os.path.dirname(CREDENTIALS_FILE), exist_ok=True)
if not os.path.exists(CREDENTIALS_FILE):
    with open(CREDENTIALS_FILE, 'w') as f:
        f.write('user1,password1,500\n')
        f.write('user2,password2,1000\n')


# Functions for logging transactions and generating/verifying MAC
def log_transaction(client_id, action, timestamp):
    global MAC_KEY
    log_entry = f"{client_id}\t{action}\t{timestamp}"
    log_entry += f",{generate_mac('balance', MAC_KEY).hex()}"
    log_entry = encrypt_message(log_entry)
    with open("encrypted_audit_log.txt", "ab") as fi:
        fi.write(log_entry)
        fi.write(b'\n')


def generate_mac(data, key):
    HMAC = hashlib.new('sha256')
    HMAC.update(key.encode('utf-8'))
    HMAC.update(data.encode('utf-8'))
    return HMAC.digest()


def verify_mac(data, expected_mac, key):
    HMAC = hashlib.new('sha256')
    HMAC.update(key.encode('utf-8'))
    HMAC.update(data.encode('utf-8'))
    return HMAC.digest() == expected_mac


# Encryption/decryption functions using AES
def encrypt_message(message):
    cipher = AES.new(SHARED_KEY, AES.MODE_ECB)
    return base64.b64encode(cipher.encrypt(pad(message.encode('utf-8'), BLOCK_SIZE)))


def decrypt_message(encrypted_message):
    cipher = AES.new(SHARED_KEY, AES.MODE_ECB)
    return unpad(cipher.decrypt(base64.b64decode(encrypted_message)), BLOCK_SIZE).decode('utf-8')


# Generate nonce for protocol authentication
def generate_nonce():
    return base64.b64encode(get_random_bytes(BLOCK_SIZE)).decode('utf-8')


# Functions for user data management
def get_user_data(username):
    if not os.path.exists(CREDENTIALS_FILE):
        return None, '0'
    with open(CREDENTIALS_FILE, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            if len(parts) == 3:
                stored_username, stored_password, balance = parts
                if stored_username == username:
                    return stored_password, balance
    return None, '0'


def update_credentials(username, password, balance):
    lines = []
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, 'r') as file:
            lines = [line for line in file if not line.startswith(username + ',')]
    lines.append(f"{username},{password},{balance}\n")
    with open(CREDENTIALS_FILE, 'w') as file:
        file.writelines(lines)


# Generate random key
def generate_random_key(length):
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


# Client handling function
def handle_client(conn, addr):
    global MAC_KEY, MASTER_SECRET, DEK
    print(f"\nConnected by {addr}")
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            decrypted_data = decrypt_message(data)
            if not decrypted_data:
                print("Decryption failed.")
                break
            parts = decrypted_data.split(',')
            command = parts[0]
            username = parts[1] if len(parts) > 1 else ""
            args = parts[2:] if len(parts) > 2 else []

            if command == 'login_username':
                print(f"\nUsername and nonce received from {addr}")
                stored_password, _ = get_user_data(username)
                if not stored_password:
                    conn.sendall(encrypt_message("Login Failed. Username not found in Database."))
                    print(f"\nServer Response for {addr}: Login failed. Username Does not Exist")
                    continue
                server_nonce = generate_nonce()
                conn.sendall(encrypt_message(f"server_nonce,{server_nonce}"))
                print(f"Server nonce sent to {addr}")

            elif command == 'login_password':
                print(f"\nPassword and nonce received from {addr}")
                stored_password, _ = get_user_data(username)
                if stored_password != args[0]:
                    conn.sendall(encrypt_message("Login Failed. Incorrect Password"))
                    print(f"\nServer Response for {addr}: Login failed. Password Did Not Match")
                    continue
                MASTER_SECRET = generate_nonce()
                MAC_KEY = generate_random_key(32)
                DEK = generate_random_key(32)
                response = f"auth_complete,master_secret,{MASTER_SECRET},{MAC_KEY},{DEK}"
                conn.sendall(encrypt_message(response))
                print(f"Server Response for {addr}: Login successful.")
                print(f"AUTHENTICATION COMPLETE FOR {addr}. Master Secret, MAC Key, and DEK sent to {addr}.\n")

            elif command == 'register':
                stored_password, _ = get_user_data(username)
                if stored_password is not None:
                    conn.sendall(encrypt_message("Registration Failed, Username already exists."))
                    continue
                update_credentials(username, args[0], '0')
                conn.sendall(encrypt_message("Registration Success, Account created."))

            elif command in ['deposit', 'withdraw', 'balance']:
                stored_password, balance = get_user_data(username)
                if command == 'deposit':
                    if verify_mac(command, bytes.fromhex(args[2]), MAC_KEY):
                        amount = int(args[1])
                        new_balance = str(int(balance) + amount)
                        update_credentials(username, stored_password, new_balance)
                        mac_key = generate_mac("deposit", MAC_KEY).hex()
                        conn.sendall(encrypt_message(f"New Balance After Deposit: {new_balance}|{mac_key}"))
                        log_transaction(username, "deposit", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                elif command == 'withdraw':
                    if verify_mac(command, bytes.fromhex(args[2]), MAC_KEY):
                        amount = int(args[1])
                        if int(balance) >= amount:
                            new_balance = str(int(balance) - amount)
                            update_credentials(username, stored_password, new_balance)
                            mac_key = generate_mac("withdraw", MAC_KEY).hex()
                            conn.sendall(encrypt_message(f"New Balance After Withdrawal: {new_balance}|{mac_key}"))
                        else:
                            mac_key = generate_mac("fail", MAC_KEY).hex()
                            conn.sendall(encrypt_message(f"Withdraw Failed. Insufficient funds.|{mac_key}"))
                elif command == 'balance':
                    if verify_mac(command, bytes.fromhex(args[2]), MAC_KEY):
                        mac_key = generate_mac("balance", MAC_KEY).hex()
                        conn.sendall(encrypt_message(f"Current Balance: {balance}|{mac_key}"))
                log_transaction(username, command, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    finally:
        conn.close()
        print(f"\nConnection closed for {addr}")


# Start the server
def start_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print("\nBank Server is up and running, waiting for connections...")
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr)).start()


if __name__ == '__main__':
    start_server()
