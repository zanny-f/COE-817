import hashlib
import socket
import tkinter as tk
from tkinter import messagebox, simpledialog
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad
import base64

# Server configuration
HOST = '127.0.0.1'
PORT = 65432

# INITIALIZED SYMMETRIC KEY
SHARED_KEY = b'SymmetricAuthKey'
BLOCK_SIZE = 16

# Define the global variables outside any function
master_secret_global = None
mac_key_global = None
dek_global = None


# Socket Communication Functions
def send_to_server(s, message):
    s.sendall(encrypt_message(message))
    response = s.recv(1024)
    return decrypt_message(response)


# Authentication Functions
def generate_mac(data, key):
    HMAC = hashlib.new('sha256')
    HMAC.update(key.encode('utf-8'))
    HMAC.update(data.encode('utf-8'))
    return HMAC.digest()


def verify_mac(data, expected_mac, key):
    HMAC = hashlib.new('sha256')
    HMAC.update(key.encode('utf-8'))
    HMAC.update(data.encode('utf-8'))
    return HMAC.digest() == expected_mac


def encrypt_message(message):
    cipher = AES.new(SHARED_KEY, AES.MODE_ECB)
    return base64.b64encode(cipher.encrypt(pad(message.encode(), BLOCK_SIZE)))


def decrypt_message(encrypted_message):
    cipher = AES.new(SHARED_KEY, AES.MODE_ECB)
    try:
        return unpad(cipher.decrypt(base64.b64decode(encrypted_message)), BLOCK_SIZE).decode()
    except (ValueError, KeyError) as e:
        print(f"Decryption failed: {e}")
        return None


# Main GUI Functions
def main_window():
    root = tk.Tk()
    root.title("ATM Banking System")
    root.geometry("400x300")
    root.attributes("-topmost", True)

    label = tk.Label(root, text="Welcome to ATM Banking System!", font=("Helvetica", 16))
    label.pack(pady=20)

    login_button = tk.Button(root, text="Login", command=lambda: login_window(root))
    login_button.pack(pady=10)

    register_button = tk.Button(root, text="Register", command=lambda: register_window(root))
    register_button.pack(pady=10)

    root.mainloop()


def login_window(main_root):
    main_root.destroy()
    login_root = tk.Tk()
    login_root.title("Login")
    login_root.geometry("300x200")

    username_label = tk.Label(login_root, text="Username:")
    username_label.pack(pady=5)
    username_entry = tk.Entry(login_root)
    username_entry.pack(pady=5)
    password_label = tk.Label(login_root, text="Password:")
    password_label.pack(pady=5)
    password_entry = tk.Entry(login_root, show="*")
    password_entry.pack(pady=5)

    login_button = tk.Button(login_root, text="Login", command=lambda: login_process(login_root,
                                                                                     username_entry.get(),
                                                                                     password_entry.get()))
    login_button.pack(pady=10)

    login_root.mainloop()


def login_process(login_root, username, password):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        response = send_to_server(s, f"login_username,{username}")
        if response and "server_nonce" in response:
            server_nonce = response.split(',')[1]
            response = send_to_server(s, f"login_password,{username},{password},{server_nonce}")
            if response.startswith("auth_complete"):
                parts = response.split(",")
                if len(parts) == 5:
                    _, _, master_secret, mac_key, dek = parts
                    global master_secret_global, mac_key_global, dek_global
                    master_secret_global = master_secret
                    mac_key_global = mac_key
                    dek_global = dek
                    print("Keys received from server:")
                    print("Master Secret:", master_secret_global)
                    print("MAC Key:", mac_key_global)
                    print("DEK:", dek_global)
                    login_root.destroy()
                    bank_operations_window(username, password)
                else:
                    print("Invalid response format from server")
        else:
            print("Response from server:", response)
            login_root.destroy()
            messagebox.showerror("Authentication Failed", "Username or password is incorrect.")
            main_window()
            login_root.destroy()


def bank_operations_window(username, password):
    bank_root = tk.Tk()
    bank_root.title("Bank Operations")
    bank_root.geometry("400x300")

    welcome_label = tk.Label(bank_root, text=f"Welcome, {username}!", font=("Helvetica", 16))
    welcome_label.pack(pady=20)

    deposit_button = tk.Button(bank_root, text="Deposit", command=lambda: perform_operation(bank_root, "deposit",
                                                                                            username, password))
    deposit_button.pack(pady=10)
    withdraw_button = tk.Button(bank_root, text="Withdraw", command=lambda: perform_operation(bank_root, "withdraw",
                                                                                              username, password))
    withdraw_button.pack(pady=10)
    balance_button = tk.Button(bank_root, text="Check Balance", command=lambda: perform_operation(bank_root, "balance",
                                                                                                  username, password))
    balance_button.pack(pady=10)
    logout_button = tk.Button(bank_root, text="Logout", command=bank_root.destroy)
    logout_button.pack(pady=10)

    bank_root.mainloop()


def perform_operation(login_root, operation, username, password):
    amount = None
    if operation != "balance":
        amount = simpledialog.askinteger("Amount", f"Enter {operation} amount:")
        if amount is None:
            return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))

        mac_key = generate_mac(operation, mac_key_global).hex()
        response = send_to_server(s, f"{operation},{username},{password},{amount},{mac_key}")
        response = response.split("|")
        print(response)
        if response is None:
            messagebox.showerror("Error", "An error occurred. Please try again later.")
            return

        if response[0] and "Insufficient funds" in response[0]:
            verify_mac("fail", bytes.fromhex(response[1]), mac_key_global)
            messagebox.showwarning("Insufficient Funds", "Insufficient funds. Please try a different amount.")
        else:
            if verify_mac(operation, bytes.fromhex(response[1]), mac_key_global):
                if operation == "balance":
                    messagebox.showinfo("Success", f"Balance check successful.\n{response[0]}")
                else:
                    messagebox.showinfo("Success", f"{operation.capitalize()} successful.\n{response[0]}")

        if messagebox.askyesno("Continue?", "Would you like to perform another operation?"):
            return
        else:
            login_root.destroy()


def register_window(main_root):
    main_root.destroy()
    register_root = tk.Tk()
    register_root.title("Register")
    register_root.geometry("300x200")

    username_label = tk.Label(register_root, text="Username:")
    username_label.pack(pady=5)
    username_entry = tk.Entry(register_root)
    username_entry.pack(pady=5)
    password_label = tk.Label(register_root, text="Password:")
    password_label.pack(pady=5)
    password_entry = tk.Entry(register_root, show="*")
    password_entry.pack(pady=5)

    register_button = tk.Button(register_root, text="Register", command=lambda: register_process(register_root,
                                                                                                 username_entry.get(),
                                                                                                 password_entry.get()))
    register_button.pack(pady=10)

    register_root.mainloop()


def register_process(register_root, username, password):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        response = send_to_server(s, f"register,{username},{password}")
        if "Registration Success" in response:
            print("Server Response:", response)
        elif "Registration Failed" in response:
            print("Server Response:", response)
            messagebox.showerror("Registration Failed", "Username already registered.")
        else:
            print("Unexpected server response:", response)
        register_root.destroy()
        main_window()


if __name__ == "__main__":
    main_window()
