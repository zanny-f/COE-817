# PHASE1: client_B.py
import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

# Function to create a socket and establish a connection to the server
def create_client_socket(ip, port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((ip, port))  # Connects to the server at the given IP address and port
    return client_socket

# Generate an RSA key pair for Client B
client_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
    backend=default_backend()
)
client_public_key = client_private_key.public_key()

# Serialize the public key for transmission to the server
client_public_key_pem = client_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
print("\nClient B Public Key:\n", client_public_key_pem.decode())  # Display the public key for demonstration

# Serialize and display the private key (not recommended outside of a demonstration context)
client_private_key_pem = client_private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
print("Client B Private Key:\n", client_private_key_pem.decode())

# Connect to the server and send the public key
client_socket = create_client_socket('localhost', 65432)
client_socket.sendall(client_public_key_pem)

# Receive encrypted data from the server
data_received = client_socket.recv(4096)
_, encrypted_kb = data_received.split(b"separator")  # Split received data to extract encrypted KB

# Function to decrypt the encrypted message using Client B's private key
def decrypt_with_client_private_key(encrypted_message):
    return client_private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

# Decrypt KB using Client B's private key and display the result
kb = decrypt_with_client_private_key(encrypted_kb)
print("Decrypted Master Key KB:", kb.hex())

# Close the socket once communication is complete
client_socket.close()
