# PHASE1: client_A.py
import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

# Function to create and connect a client socket to the server
def create_client_socket(ip, port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((ip, port))  # Establish connection to the server at specified IP and port
    return client_socket

# Generate RSA key pair for Client A
client_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
    backend=default_backend()
)
client_public_key = client_private_key.public_key()

# Serialize the public key to send to the server
client_public_key_pem = client_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
print("\nClient A Public Key:\n", client_public_key_pem.decode())  # Print the serialized public key for demonstration

# Serialize and print the private key for demonstration purposes (not recommended in real applications)
client_private_key_pem = client_private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
print("Client A Private Key:\n", client_private_key_pem.decode())

# Connect to the server and send the public key
client_socket = create_client_socket('localhost', 65432)
client_socket.sendall(client_public_key_pem)

# Receive the encrypted keys from the server
data_received = client_socket.recv(4096)
encrypted_ka, _ = data_received.split(b"separator")  # Split received data to extract encrypted KA

# Function to decrypt messages with the client's private key
def decrypt_with_client_private_key(encrypted_message):
    return client_private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

# Decrypt KA using the client's private key and print the decrypted key
ka = decrypt_with_client_private_key(encrypted_ka)
print("Decrypted Master Key KA:", ka.hex())

# Close the socket after completion of communication
client_socket.close()
