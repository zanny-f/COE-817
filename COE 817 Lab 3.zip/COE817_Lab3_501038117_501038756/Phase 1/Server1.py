# PHASE1: server.py
import socket
import threading
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.fernet import Fernet

# Function to create and configure the server socket
def create_server_socket(ip, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((ip, port))  # Binds the socket to the specified IP and port
    server_socket.listen(5)  # Configures the socket to listen for incoming connections, with a queue of up to 5
    return server_socket

# Function to handle client connections
def handle_client_connection(client_socket, client_address, kdc_private_key, ka, kb):
    try:
        # Receives the client's public key
        client_public_key_bytes = client_socket.recv(1024)
        client_public_key = serialization.load_pem_public_key(client_public_key_bytes, backend=default_backend())

        # Encrypts KA and KB with the client's public key using RSA OAEP padding
        encrypted_ka = client_public_key.encrypt(
            ka,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        encrypted_kb = client_public_key.encrypt(
            kb,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        # Sends the encrypted KA and KB back to the client
        client_socket.sendall(encrypted_ka + b"separator" + encrypted_kb)
    except Exception as e:
        # Handles any errors that occur during the process
        print(f"Error handling client {client_address}: {e}")
    finally:
        # Ensures the client socket is closed after handling
        client_socket.close()

# Function to create a new thread for each client connection
def client_thread(client_socket, client_address, kdc_private_key, ka, kb):
    handle_client_connection(client_socket, client_address, kdc_private_key, ka, kb)

# Generates the server's RSA key pair
kdc_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
    backend=default_backend()
)
server_public_key = kdc_private_key.public_key()

# Serializes and prints the server's public key for demonstration
server_public_key_pem = server_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
print("\nServer Public Key:\n", server_public_key_pem.decode())

# Serializes and prints the server's private key (for demonstration purposes only)
server_private_key_pem = kdc_private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
print("Server Private Key:\n", server_private_key_pem.decode())

# Generates symmetric keys KA and KB for A and B
ka = Fernet.generate_key()
kb = Fernet.generate_key()

# Creates the server socket and starts listening for connections
server_socket = create_server_socket('localhost', 65432)
print("Server KDC is running and waiting for connections...")

try:
    # Accepts new connections in an infinite loop
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"\nAccepted connection from {client_address}")
        # Starts a new thread for each accepted connection
        threading.Thread(target=client_thread, args=(client_socket, client_address, kdc_private_key, ka, kb)).start()
finally:
    # Ensures the server socket is closed when the server stops running
    server_socket.close()
