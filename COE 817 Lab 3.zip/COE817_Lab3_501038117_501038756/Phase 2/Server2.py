# PHASE2: server.py
import socket
import threading
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.fernet import Fernet

# Creates a server socket, binds it to the specified IP address and port, and starts listening for incoming connections
def create_server_socket(ip, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((ip, port))
    server_socket.listen(5)  # Can handle up to 5 connection requests in queue
    return server_socket

# Handles each client connection: receives the client's public key, encrypts the session key (KAB) with it, and sends it back
def handle_client_connection(client_socket, client_address, kdc_private_key, kab):
    try:
        # Waits to receive the public key from the client
        client_public_key_bytes = client_socket.recv(1024)
        client_public_key = serialization.load_pem_public_key(client_public_key_bytes, backend=default_backend())

        # Encrypts the session key KAB with the received client's public key
        encrypted_kab = client_public_key.encrypt(
            kab,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        # Sends the encrypted session key back to the client
        client_socket.sendall(encrypted_kab)
    except Exception as e:
        # Logs any exceptions during handling
        print(f"Error handling client {client_address}: {e}")
    finally:
        # Closes the client socket after sending the encrypted session key or if an error occurs
        client_socket.close()

# Creates a separate thread for handling each client connection to ensure concurrent processing
def client_thread(client_socket, client_address, kdc_private_key, kab):
    handle_client_connection(client_socket, client_address, kdc_private_key, kab)

# Generates RSA key pair for KDC (Key Distribution Center)
kdc_private_key, kdc_public_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend()), rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend()).public_key()

# Generates a shared session key (KAB) for A and B
kab = Fernet.generate_key()

# Initializes the server socket and starts listening for connections
server_socket = create_server_socket('localhost', 65432)
print("Server KDC is running and waiting for connections...")

try:
    # Continuously accepts new client connections and handles them in separate threads
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"\nAccepted connection from {client_address}")
        threading.Thread(target=client_thread, args=(client_socket, client_address, kdc_private_key, kab)).start()
finally:
    # Ensures the server socket is closed when the server process is terminated
    server_socket.close()
