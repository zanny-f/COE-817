# PHASE2: client_A.py
import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

# Establishes a TCP connection to the server
def create_client_socket(ip, port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((ip, port))  # Connects to the specified IP address and port
    return client_socket

# Generates RSA key pair for Client A
client_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
client_public_key = client_private_key.public_key()

# Serializes the public key to PEM format to send to the server
client_public_key_pem = client_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
print("\nClient A Public Key:\n", client_public_key_pem.decode())  # Prints the public key for demonstration purposes

# Initiates connection to the server and sends the serialized public key
client_socket = create_client_socket('localhost', 65432)
client_socket.sendall(client_public_key_pem)

# Receives the encrypted session key (KAB) from the server
encrypted_kab = client_socket.recv(4096)  # Waits to receive data from the server

# Decrypts the received encrypted session key with the client's private key
def decrypt_with_private_key(private_key, ciphertext):
    # Uses RSA OAEP padding for decryption, specifying SHA-256 as the hash function
    return private_key.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),  # Specifies the mask generation function
            algorithm=hashes.SHA256(),  # Specifies the hashing algorithm
            label=None  # Optional label for additional data; not used here
        )
    )

# Decrypts the received encrypted KAB and prints it
kab = decrypt_with_private_key(client_private_key, encrypted_kab)
print("Decrypted Session Key KAB in Client A:", kab.hex())

# Closes the socket after the communication is completed
client_socket.close()
