from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import socket
import time
import json

# Function to generate RSA keys
def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

private_key, public_key = generate_rsa_keys()

# Save the public key to a file for Bob to read
with open('alice_public.pem', 'wb') as f:
    f.write(public_key)

# Message
message = b'Hello Bob'

# Timestamp
timestamp = time.time()

# Create a digest of the message
message_digest = SHA256.new(message + str(timestamp).encode())

# Sign the digest with the private key
private_key_rsa = RSA.import_key(private_key)
signature = pkcs1_15.new(private_key_rsa).sign(message_digest)

# Send the message, timestamp, and signature to Bob
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 12345))
data_to_send = {
    'message': message.decode(),
    'timestamp': timestamp,
    'signature': signature.hex()
}
client_socket.send(json.dumps(data_to_send).encode())

client_socket.close()
print("Signature sent to Bob.")
