from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import socket
import time
import json

# Function to load Alice's public key from a file
def load_alice_public_key():
    with open('alice_public.pem', 'r') as f:
        return RSA.import_key(f.read())

# Server setup
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(1)
print("Server is listening for incoming connections.")

# Accept connection from Alice
client_socket, client_address = server_socket.accept()
print(f"Connection from {client_address} has been established.")

# Receive data from Alice
data = client_socket.recv(1024).decode()
data = json.loads(data)

# Extract the message, timestamp, and signature from the received data
received_message = data['message'].encode()
received_timestamp = data['timestamp']
received_signature = bytes.fromhex(data['signature'])

# Load Alice's public key
alice_public_key = load_alice_public_key()

# Create a digest of the received message
message_digest = SHA256.new(received_message + str(received_timestamp).encode())

# Verify the signature
try:
    pkcs1_15.new(alice_public_key).verify(message_digest, received_signature)
    print("The signature is valid.")

    # Check the timestamp to ensure the message is not a replay
    if time.time() - received_timestamp < 60:  # Allow a 60-second window
        print("The message is fresh.")
        print(received_message.decode())
    else:
        print("The message is not fresh. Possible replay attack detected.")
except (ValueError, TypeError):
    print("The signature is not valid.")

# Close the sockets
client_socket.close()
server_socket.close()
