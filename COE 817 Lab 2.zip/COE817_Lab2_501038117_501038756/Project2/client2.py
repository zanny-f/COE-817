from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import socket
import sys

# Function for the creation of a pair of RSA keys
# Function for generating the RSA keys
def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key, public_key = key.exportKey(), key.publickey().exportKey()
    return private_key, public_key

def get_port(default=1500):
    if len(sys.argv) > 1:
        return int(sys.argv[1])
    return default

# Create Client
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('localhost', get_port()))
print(f"Connected to server on{('localhost', get_port())}")

# Generate Alice's keys, Nonce and ID:
Na = int.to_bytes(187774075509857287, length=8, byteorder='big')
# Na = Random.get_random_bytes(8)
IDa = b'Alice'
alice_private_key, alice_public_key = generate_rsa_keys()

# Step 0 for Set-up: Exchange public keys
client.send(alice_public_key)
bob_public_key = client.recv(2048)

# Convert Bob's public key from PEM to RSA key
bob_public_key_rsa = RSA.importKey(bob_public_key)
cipher_for_bob = PKCS1_OAEP.new(bob_public_key_rsa)

# Convert Alice's private key from PEM to RSA key for decryption
alice_private_key_rsa = RSA.importKey(alice_private_key)
cipher_for_alice = PKCS1_OAEP.new(alice_private_key_rsa)

# Step 1: Send Nonce and ID to Server
send_message = IDa + b'||' + Na
client.send(send_message)
print("\n[Sent Message 1]")
print(f"[Sent ID and Nonce to Server] ID: {IDa.decode()}, Nonce: {int.from_bytes(Na, byteorder='big')}")

full_message = b''
while True:
    part = client.recv(4096)
    full_message += part
    if len(part) < 4096:
        break

# Step 2: Receive Encrypted Nonce from Server and Decrypt it
print("\n[Received Message 2]")
print(f"[Received Encrypted Nonce from Server] {full_message.hex()}")

# Decrypt using Alice's private key
try:
    decrypted_nonce_bob = cipher_for_alice.decrypt(full_message)
    print("\n[Decrypted Message 2]")
    print(f"[Decrypted Nonce] {int.from_bytes(decrypted_nonce_bob, byteorder='big')}")
except (ValueError, IndexError) as e:
    print("Decryption failed:", e)
    
# Step 3: Encrypt and Send Authentication Message to Server (Bob)
send_message = b'Authentication Successful'
send_encrypted_message = cipher_for_bob.encrypt(send_message)
client.send(send_encrypted_message)
print(f"\n[Sent Message 3]: {send_encrypted_message.hex()}")

# Close the client connection
client.close()

