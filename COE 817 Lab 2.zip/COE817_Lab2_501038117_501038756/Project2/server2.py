from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import socket
import sys
from Crypto.Random import get_random_bytes  # Correctly import get_random_bytes

# Function for the creation of a pair of RSA keys
def generate_keys():
    key = RSA.generate(2048)   # generate public and private keys
    private_key = key.export_key(format='PEM')
    public_key = key.publickey().export_key(format='PEM')
    return private_key, public_key

def get_port(default=1500):
    if len(sys.argv) > 1:
        return int(sys.argv[1])
    return default

# Create Server
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('localhost', get_port()))
server.listen(1)
print("Server is now listening for incoming connections.")
client_sock, client_addr = server.accept()
print('Got connection from', client_addr)

# Generate Bob's keys, Nonce and ID:
Nb = get_random_bytes(16)  # Correctly generate 16 random bytes
IDb = b'Bob'
bob_private_key, bob_public_key = generate_keys()

# Step 0 for Set-up: Exchange public keys
alice_public_key = client_sock.recv(2048)
client_sock.send(bob_public_key)

# Convert Alice's public key from PEM to RSA key for encryption
alice_public_key_rsa = RSA.importKey(alice_public_key)
cipher_for_alice = PKCS1_OAEP.new(alice_public_key_rsa)

# Convert Bob's private key from PEM to RSA key for decryption
bob_private_key_rsa = RSA.importKey(bob_private_key)
cipher_for_bob = PKCS1_OAEP.new(bob_private_key_rsa)

# Step 1: Receive client_sock's Nonce and ID
received_message = client_sock.recv(1024)
IDa, Na = received_message.split(b'||')
print(f"\n[Received Message 1] ID: {IDa.decode()}, Nonce: {Na.hex()}")

# Step 2: Encrypt and Send Bob's Nonce to Client
encrypted_nonce_bob = cipher_for_alice.encrypt(Nb)
client_sock.send(encrypted_nonce_bob)
print("\n[Sent Message 2]")
print(f"[Sent Encrypted Nonce(Nb) to Client] {encrypted_nonce_bob.hex()}")

# Step 3: Receive Encrypted Message from Client (Alice)
received_encrypted_message = client_sock.recv(2048)
print("\n[Received Message 3]")
print(f"[Received Encrypted Message from Client] {received_encrypted_message.hex()}")

# Decrypt using Bob's private key
decrypted_message = cipher_for_bob.decrypt(received_encrypted_message)
print("\n[Decrypted Message 3]")
print(f"[Decrypted Message] {decrypted_message.decode()}")

client_sock.close()
server.close()