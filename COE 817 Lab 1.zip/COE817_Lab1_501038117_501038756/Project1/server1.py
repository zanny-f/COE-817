import socket
import threading
import sys

# Mapping of alphabets to numeric values for encryption and decryption
alphabet_to_numbers = {chr(65 + i): i for i in range(26)}
numbers_to_alphabet = {i: chr(65 + i) for i in range(26)}

def encrypt(message, key):
    """
    Encrypts a message using a Vigenère-like cipher.

    :param message: The plaintext message to encrypt.
    :param key: The encryption key.
    :return: The encrypted message.
    """
    message = message.upper()
    encrypted_message = []

    for i, char in enumerate(message):
        if char in alphabet_to_numbers:
            key_shift = alphabet_to_numbers[key[i % len(key)]]
            encrypted_index = (alphabet_to_numbers[char] + key_shift) % 26
            encrypted_message.append(numbers_to_alphabet[encrypted_index])
        else:
            encrypted_message.append(char)

    return ''.join(encrypted_message)

def decrypt(message, key):
    """
    Decrypts a message encrypted with the Vigenère-like cipher.

    :param message: The encrypted message to decrypt.
    :param key: The decryption key.
    :return: The decrypted message.
    """
    message = message.upper()
    decrypted_message = []

    for i, char in enumerate(message):
        if char in alphabet_to_numbers:
            key_shift = alphabet_to_numbers[key[i % len(key)]]
            decrypted_index = (alphabet_to_numbers[char] - key_shift + 26) % 26
            decrypted_message.append(numbers_to_alphabet[decrypted_index])
        else:
            decrypted_message.append(char)

    return ''.join(decrypted_message)

# Pre-defined responses for certain questions
responses = {
    'HOW TALL IS MOUNT EVEREST?': 'Mount Everest is 29,032 feet tall.',
    'WHAT IS THE CAPITAL OF FRANCE?': 'The capital of France is Paris.',
    'HOW DOES THE INTERNET WORK?': 'The Internet is a network of networks sharing data.'
}

def get_port(default_port=1500):
    """
    Retrieves the port number from command line arguments or uses a default.

    :param default_port: The default port to use if none is specified.
    :return: The port number.
    """
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
            return port
        except ValueError:
            print(f"Invalid port number provided. Using default port: {default_port}")
    return default_port

def handle_client(connection, address):
    """
    Handles a client connection.

    :param connection: The socket object for the client.
    :param address: The address of the client.
    """
    print(f"[NEW CONNECTION] {address} connected.")

    while True:
        message = connection.recv(1024).decode()
        if not message:
            break  # End the loop if no message is received

        decrypted_message = decrypt(message, keyword)
        print(f"[{address}] Decrypted Question: {decrypted_message}")

        if decrypted_message in ["EXIT", "BYE"]:
            print(f"[{address}] Connection closed by the client.")
            break

        response = responses.get(decrypted_message, "Sorry, I don't understand that question.")
        encrypted_response = encrypt(response, keyword)
        connection.send(encrypted_response.encode())

    connection.close()
    print(f"[CONNECTION CLOSED] {address}")

def start_server():
    """
    Starts the server and listens for incoming connections.
    """
    server.listen()
    print("[SERVER STARTED] Listening for connections...")

    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")

# Server setup
PORT = get_port()
SERVER = 'localhost'
ADDRESS = (SERVER, PORT)
keyword = "TMU"  # Encryption/Decryption keyword

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDRESS)

# Start the server
start_server()
