import socket
import sys

# Mapping of alphabets to numeric values and vice versa for easy encryption/decryption
alphabet_to_numbers = {chr(i + 65): i for i in range(26)}
numbers_to_alphabet = {i: chr(i + 65) for i in range(26)}

def encrypt_message(message, key):
    """
    Encrypts a message using a Vigenère cipher-like method.

    :param message: The message to encrypt.
    :param key: The keyword used for encryption.
    :return: Encrypted message.
    """
    message = message.upper()
    key_indices = [alphabet_to_numbers[char] for char in key]
    encrypted_message = ''

    for i, char in enumerate(message):
        if char in alphabet_to_numbers:
            key_value = key_indices[i % len(key)]
            new_index = (alphabet_to_numbers[char] + key_value) % 26
            encrypted_message += numbers_to_alphabet[new_index]
        else:
            encrypted_message += char

    return encrypted_message

def decrypt_message(message, key):
    """
    Decrypts a message encrypted with the Vigenère cipher-like method.

    :param message: The encrypted message to decrypt.
    :param key: The keyword used for decryption.
    :return: Decrypted message.
    """
    message = message.upper()
    key_indices = [alphabet_to_numbers[char] for char in key]
    decrypted_message = ''

    for i, char in enumerate(message):
        if char in alphabet_to_numbers:
            key_value = key_indices[i % len(key)]
            new_index = (alphabet_to_numbers[char] - key_value) % 26
            decrypted_message += numbers_to_alphabet[new_index]
        else:
            decrypted_message += char

    return decrypted_message

def get_port_number(default=1500):
    """
    Retrieves the port number from the command line arguments or uses the default.

    :param default: Default port number.
    :return: Port number.
    """
    if len(sys.argv) > 1:
        try:
            return int(sys.argv[1])
        except ValueError:
            print(f"Invalid port number. Using default port {default}.")
    return default

def setup_client_connection(server='localhost', port=1500):
    """
    Sets up the client socket and connects to the server.

    :param server: The server address.
    :param port: The port number.
    :return: The client socket.
    """
    address = (server, port)
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(address)
    return client_socket

# Main script execution starts here
PORT = get_port_number()  # Determine port number
client_socket = setup_client_connection(port=PORT)  # Set up client
encryption_key = "TMU"  # Define the encryption/decryption key

# Questions available for the user to choose from
questions = {
    1: 'How tall is Mount Everest?',
    2: 'What is the Capital of France?',
    3: 'How does the Internet work?'
}

while True:
    # Display questions and prompt for user input
    user_input = input('Choose a question (number) or type "Exit" to quit:\n' + '\n'.join([f'{num}: {q}' for num, q in questions.items()]) + '\n')

    if user_input.lower() in ['exit', 'bye']:
        print("Terminating connection...")
        client_socket.close()
        break

    try:
        choice = int(user_input)
        question = questions.get(choice, None)
        if question:
            encrypted_question = encrypt_message(question, encryption_key)
            client_socket.send(encrypted_question.encode())  # Send encrypted question
            
            encrypted_response = client_socket.recv(1024).decode()  # Receive encrypted response
            print(f"Encrypted: {encrypted_response}")
            decrypted_response = decrypt_message(encrypted_response, encryption_key)
            print(f"Answer: {decrypted_response}")
        else:
            print("Invalid choice. Please select a valid question number.")
    except ValueError:
        print("Invalid input. Please enter a number or 'Exit'/'Bye' to quit.")
